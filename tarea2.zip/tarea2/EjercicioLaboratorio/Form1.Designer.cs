﻿namespace EjercicioLaboratorio
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TabControl = new TabControl();
            Mascota = new TabPage();
            label2 = new Label();
            label1 = new Label();
            EdadMascotaTextBox = new TextBox();
            EstadoMascotaComboBox = new ComboBox();
            NombreMascotaTextBox = new TextBox();
            DueñoComboBox = new ComboBox();
            ListBoxMascotas = new ListBox();
            EliminarMascota = new Button();
            EditarMascota = new Button();
            AgregarMascota = new Button();
            Dueño = new TabPage();
            CorreoDueño = new Label();
            ApellidoDueño = new Label();
            NombreDueño = new Label();
            ListBoxDueños = new ListBox();
            EmailDueñoTextBox = new TextBox();
            ApellidoDueñoTextBox = new TextBox();
            NombreDueñoTextBox = new TextBox();
            AgregarDueño = new Button();
            EditarDueño = new Button();
            EliminarDueño = new Button();
            EstadoMascota = new TabPage();
            ComboBoxEstados = new ComboBox();
            label5 = new Label();
            DescripcionEstadoTextBox = new TextBox();
            AgregarEstadoButton = new Button();
            EditarEstadoButton = new Button();
            EliminarEstadoButton = new Button();
            TabControl.SuspendLayout();
            Mascota.SuspendLayout();
            Dueño.SuspendLayout();
            EstadoMascota.SuspendLayout();
            SuspendLayout();
            // 
            // TabControl
            // 
            TabControl.Controls.Add(Mascota);
            TabControl.Controls.Add(Dueño);
            TabControl.Controls.Add(EstadoMascota);
            TabControl.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            TabControl.Location = new Point(97, 76);
            TabControl.Name = "TabControl";
            TabControl.SelectedIndex = 0;
            TabControl.Size = new Size(751, 400);
            TabControl.TabIndex = 0;
            // 
            // Mascota
            // 
            Mascota.Controls.Add(label2);
            Mascota.Controls.Add(label1);
            Mascota.Controls.Add(EdadMascotaTextBox);
            Mascota.Controls.Add(EstadoMascotaComboBox);
            Mascota.Controls.Add(NombreMascotaTextBox);
            Mascota.Controls.Add(DueñoComboBox);
            Mascota.Controls.Add(ListBoxMascotas);
            Mascota.Controls.Add(EliminarMascota);
            Mascota.Controls.Add(EditarMascota);
            Mascota.Controls.Add(AgregarMascota);
            Mascota.Location = new Point(4, 37);
            Mascota.Name = "Mascota";
            Mascota.Size = new Size(743, 359);
            Mascota.TabIndex = 0;
            Mascota.Text = "Mascota";
            Mascota.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(61, 100);
            label2.Name = "label2";
            label2.Size = new Size(144, 28);
            label2.TabIndex = 9;
            label2.Text = "Edad Mascota";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(51, 23);
            label1.Name = "label1";
            label1.Size = new Size(175, 28);
            label1.TabIndex = 8;
            label1.Text = "Nombre Mascota";
            // 
            // EdadMascotaTextBox
            // 
            EdadMascotaTextBox.Location = new Point(70, 131);
            EdadMascotaTextBox.Multiline = true;
            EdadMascotaTextBox.Name = "EdadMascotaTextBox";
            EdadMascotaTextBox.Size = new Size(125, 35);
            EdadMascotaTextBox.TabIndex = 7;
            // 
            // EstadoMascotaComboBox
            // 
            EstadoMascotaComboBox.FormattingEnabled = true;
            EstadoMascotaComboBox.Location = new Point(326, 214);
            EstadoMascotaComboBox.Name = "EstadoMascotaComboBox";
            EstadoMascotaComboBox.Size = new Size(242, 36);
            EstadoMascotaComboBox.TabIndex = 6;
            // 
            // NombreMascotaTextBox
            // 
            NombreMascotaTextBox.Location = new Point(70, 54);
            NombreMascotaTextBox.Multiline = true;
            NombreMascotaTextBox.Name = "NombreMascotaTextBox";
            NombreMascotaTextBox.Size = new Size(125, 43);
            NombreMascotaTextBox.TabIndex = 5;
            // 
            // DueñoComboBox
            // 
            DueñoComboBox.FormattingEnabled = true;
            DueñoComboBox.Location = new Point(326, 172);
            DueñoComboBox.Name = "DueñoComboBox";
            DueñoComboBox.Size = new Size(242, 36);
            DueñoComboBox.TabIndex = 4;
            // 
            // ListBoxMascotas
            // 
            ListBoxMascotas.FormattingEnabled = true;
            ListBoxMascotas.ItemHeight = 28;
            ListBoxMascotas.Items.AddRange(new object[] { "" });
            ListBoxMascotas.Location = new Point(301, 54);
            ListBoxMascotas.Name = "ListBoxMascotas";
            ListBoxMascotas.Size = new Size(204, 60);
            ListBoxMascotas.TabIndex = 3;
            // 
            // EliminarMascota
            // 
            EliminarMascota.Location = new Point(91, 277);
            EliminarMascota.Name = "EliminarMascota";
            EliminarMascota.Size = new Size(94, 35);
            EliminarMascota.TabIndex = 2;
            EliminarMascota.Text = "Eliminar";
            EliminarMascota.UseVisualStyleBackColor = true;
            EliminarMascota.Click += EliminarMascota_Click;
            // 
            // EditarMascota
            // 
            EditarMascota.Location = new Point(111, 245);
            EditarMascota.Name = "EditarMascota";
            EditarMascota.Size = new Size(94, 34);
            EditarMascota.TabIndex = 1;
            EditarMascota.Text = "Editar";
            EditarMascota.UseVisualStyleBackColor = true;
            EditarMascota.Click += EditarMascota_Click;
            // 
            // AgregarMascota
            // 
            AgregarMascota.Location = new Point(139, 214);
            AgregarMascota.Name = "AgregarMascota";
            AgregarMascota.Size = new Size(104, 37);
            AgregarMascota.TabIndex = 0;
            AgregarMascota.Text = "Agregar";
            AgregarMascota.UseVisualStyleBackColor = true;
            AgregarMascota.Click += AgregarMascota_Click;
            // 
            // Dueño
            // 
            Dueño.Controls.Add(CorreoDueño);
            Dueño.Controls.Add(ApellidoDueño);
            Dueño.Controls.Add(NombreDueño);
            Dueño.Controls.Add(ListBoxDueños);
            Dueño.Controls.Add(EmailDueñoTextBox);
            Dueño.Controls.Add(ApellidoDueñoTextBox);
            Dueño.Controls.Add(NombreDueñoTextBox);
            Dueño.Controls.Add(AgregarDueño);
            Dueño.Controls.Add(EditarDueño);
            Dueño.Controls.Add(EliminarDueño);
            Dueño.Location = new Point(4, 37);
            Dueño.Name = "Dueño";
            Dueño.Size = new Size(743, 359);
            Dueño.TabIndex = 1;
            Dueño.Text = "Dueño";
            Dueño.UseVisualStyleBackColor = true;
            // 
            // CorreoDueño
            // 
            CorreoDueño.AutoSize = true;
            CorreoDueño.Location = new Point(306, 148);
            CorreoDueño.Name = "CorreoDueño";
            CorreoDueño.Size = new Size(118, 56);
            CorreoDueño.TabIndex = 12;
            CorreoDueño.Text = "Correo \r\nElectrónico";
            // 
            // ApellidoDueño
            // 
            ApellidoDueño.AutoSize = true;
            ApellidoDueño.Location = new Point(306, 98);
            ApellidoDueño.Name = "ApellidoDueño";
            ApellidoDueño.Size = new Size(91, 28);
            ApellidoDueño.TabIndex = 11;
            ApellidoDueño.Text = "Apellido";
            // 
            // NombreDueño
            // 
            NombreDueño.AutoSize = true;
            NombreDueño.Location = new Point(308, 42);
            NombreDueño.Name = "NombreDueño";
            NombreDueño.Size = new Size(89, 28);
            NombreDueño.TabIndex = 10;
            NombreDueño.Text = "Nombre";
            // 
            // ListBoxDueños
            // 
            ListBoxDueños.FormattingEnabled = true;
            ListBoxDueños.ItemHeight = 28;
            ListBoxDueños.Items.AddRange(new object[] { "" });
            ListBoxDueños.Location = new Point(357, 224);
            ListBoxDueños.Name = "ListBoxDueños";
            ListBoxDueños.Size = new Size(196, 116);
            ListBoxDueños.TabIndex = 9;
            // 
            // EmailDueñoTextBox
            // 
            EmailDueñoTextBox.Location = new Point(414, 151);
            EmailDueñoTextBox.Name = "EmailDueñoTextBox";
            EmailDueñoTextBox.Size = new Size(125, 34);
            EmailDueñoTextBox.TabIndex = 8;
            // 
            // ApellidoDueñoTextBox
            // 
            ApellidoDueñoTextBox.Location = new Point(414, 91);
            ApellidoDueñoTextBox.Name = "ApellidoDueñoTextBox";
            ApellidoDueñoTextBox.Size = new Size(125, 34);
            ApellidoDueñoTextBox.TabIndex = 7;
            // 
            // NombreDueñoTextBox
            // 
            NombreDueñoTextBox.Location = new Point(414, 36);
            NombreDueñoTextBox.Name = "NombreDueñoTextBox";
            NombreDueñoTextBox.Size = new Size(125, 34);
            NombreDueñoTextBox.TabIndex = 6;
            // 
            // AgregarDueño
            // 
            AgregarDueño.Location = new Point(66, 91);
            AgregarDueño.Name = "AgregarDueño";
            AgregarDueño.Size = new Size(124, 42);
            AgregarDueño.TabIndex = 5;
            AgregarDueño.Text = "Agregar";
            AgregarDueño.UseVisualStyleBackColor = true;
            AgregarDueño.Click += AgregarDueño_Click;
            // 
            // EditarDueño
            // 
            EditarDueño.Location = new Point(96, 139);
            EditarDueño.Name = "EditarDueño";
            EditarDueño.Size = new Size(94, 46);
            EditarDueño.TabIndex = 4;
            EditarDueño.Text = "Editar";
            EditarDueño.UseVisualStyleBackColor = true;
            EditarDueño.Click += EditarDueño_Click;
            // 
            // EliminarDueño
            // 
            EliminarDueño.Location = new Point(96, 191);
            EliminarDueño.Name = "EliminarDueño";
            EliminarDueño.Size = new Size(118, 42);
            EliminarDueño.TabIndex = 3;
            EliminarDueño.Text = "Eliminar";
            EliminarDueño.UseVisualStyleBackColor = true;
            EliminarDueño.Click += EliminarDueño_Click;
            // 
            // EstadoMascota
            // 
            EstadoMascota.Controls.Add(ComboBoxEstados);
            EstadoMascota.Controls.Add(label5);
            EstadoMascota.Controls.Add(DescripcionEstadoTextBox);
            EstadoMascota.Controls.Add(AgregarEstadoButton);
            EstadoMascota.Controls.Add(EditarEstadoButton);
            EstadoMascota.Controls.Add(EliminarEstadoButton);
            EstadoMascota.Location = new Point(4, 37);
            EstadoMascota.Name = "EstadoMascota";
            EstadoMascota.Size = new Size(743, 359);
            EstadoMascota.TabIndex = 2;
            EstadoMascota.Text = "EstadoMascota";
            EstadoMascota.UseVisualStyleBackColor = true;
            // 
            // ComboBoxEstados
            // 
            ComboBoxEstados.FormattingEnabled = true;
            ComboBoxEstados.Location = new Point(313, 173);
            ComboBoxEstados.Name = "ComboBoxEstados";
            ComboBoxEstados.Size = new Size(248, 36);
            ComboBoxEstados.TabIndex = 23;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(313, 44);
            label5.Name = "label5";
            label5.Size = new Size(212, 28);
            label5.TabIndex = 20;
            label5.Text = "Estado de la mascota";
            // 
            // DescripcionEstadoTextBox
            // 
            DescripcionEstadoTextBox.Location = new Point(343, 86);
            DescripcionEstadoTextBox.Multiline = true;
            DescripcionEstadoTextBox.Name = "DescripcionEstadoTextBox";
            DescripcionEstadoTextBox.Size = new Size(171, 42);
            DescripcionEstadoTextBox.TabIndex = 16;
            // 
            // AgregarEstadoButton
            // 
            AgregarEstadoButton.Location = new Point(37, 86);
            AgregarEstadoButton.Name = "AgregarEstadoButton";
            AgregarEstadoButton.Size = new Size(124, 42);
            AgregarEstadoButton.TabIndex = 15;
            AgregarEstadoButton.Text = "Agregar";
            AgregarEstadoButton.UseVisualStyleBackColor = true;
            AgregarEstadoButton.Click += AgregarEstadoButton_Click;
            // 
            // EditarEstadoButton
            // 
            EditarEstadoButton.Location = new Point(67, 134);
            EditarEstadoButton.Name = "EditarEstadoButton";
            EditarEstadoButton.Size = new Size(94, 46);
            EditarEstadoButton.TabIndex = 14;
            EditarEstadoButton.Text = "Editar";
            EditarEstadoButton.UseVisualStyleBackColor = true;
            EditarEstadoButton.Click += EditarEstadoButton_Click;
            // 
            // EliminarEstadoButton
            // 
            EliminarEstadoButton.Location = new Point(67, 186);
            EliminarEstadoButton.Name = "EliminarEstadoButton";
            EliminarEstadoButton.Size = new Size(118, 42);
            EliminarEstadoButton.TabIndex = 13;
            EliminarEstadoButton.Text = "Eliminar";
            EliminarEstadoButton.UseVisualStyleBackColor = true;
            EliminarEstadoButton.Click += EliminarEstadoButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 0, 192);
            ClientSize = new Size(1020, 530);
            Controls.Add(TabControl);
            Name = "Form1";
            Text = "Form1";
            TabControl.ResumeLayout(false);
            Mascota.ResumeLayout(false);
            Mascota.PerformLayout();
            Dueño.ResumeLayout(false);
            Dueño.PerformLayout();
            EstadoMascota.ResumeLayout(false);
            EstadoMascota.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl TabControl;
        private TabPage Mascota;
        private Button EliminarMascota;
        private Button EditarMascota;
        private Button AgregarMascota;
        private TabPage Dueño;
        private TabPage EstadoMascota;
        private ListBox ListBoxMascotas;
        private Button AgregarDueño;
        private Button EditarDueño;
        private Button EliminarDueño;
        private ComboBox DueñoComboBox;
        private TextBox NombreMascotaTextBox;
        private ComboBox EstadoMascotaComboBox;
        private TextBox EdadMascotaTextBox;
        private Label label2;
        private Label label1;
        private TextBox EmailDueñoTextBox;
        private TextBox ApellidoDueñoTextBox;
        private TextBox NombreDueñoTextBox;
        private Label CorreoDueño;
        private Label ApellidoDueño;
        private Label NombreDueño;
        private Label label5;
        private TextBox DescripcionEstadoTextBox;
        private Button AgregarEstadoButton;
        private Button EditarEstadoButton;
        private Button EliminarEstadoButton;
        private ComboBox ComboBoxEstados;
        private ListBox ListBoxDueños;
    }
}