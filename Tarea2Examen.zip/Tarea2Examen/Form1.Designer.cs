﻿namespace Tarea2Examen
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.AgregarEstadoButton = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.AgregarMascota = new System.Windows.Forms.Button();
            this.EditarMascota = new System.Windows.Forms.Button();
            this.EliminarMascota = new System.Windows.Forms.Button();
            this.NombreMascotaTextBox = new System.Windows.Forms.TextBox();
            this.EdadMascotaTextBox = new System.Windows.Forms.TextBox();
            this.ListBoxMascotas = new System.Windows.Forms.ListBox();
            this.DueñoComboBox = new System.Windows.Forms.ComboBox();
            this.EstadoMascotaComboBox = new System.Windows.Forms.ComboBox();
            this.EliminarDueño = new System.Windows.Forms.Button();
            this.EditarDueño = new System.Windows.Forms.Button();
            this.AgregarDueño = new System.Windows.Forms.Button();
            this.ApellidoDueñoTextBox = new System.Windows.Forms.TextBox();
            this.NombreDueñoTextBox = new System.Windows.Forms.TextBox();
            this.ListBoxDueños = new System.Windows.Forms.ListBox();
            this.EmailDueñoTextBox = new System.Windows.Forms.TextBox();
            this.EliminarEstadoButton = new System.Windows.Forms.Button();
            this.EditarEstadoButton = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.DescripcionEstadoTextBox = new System.Windows.Forms.TextBox();
            this.ComboBoxEstados = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.AgregarEstadoButton.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // AgregarEstadoButton
            // 
            this.AgregarEstadoButton.Controls.Add(this.tabPage1);
            this.AgregarEstadoButton.Controls.Add(this.tabPage2);
            this.AgregarEstadoButton.Controls.Add(this.tabPage3);
            this.AgregarEstadoButton.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgregarEstadoButton.Location = new System.Drawing.Point(53, 67);
            this.AgregarEstadoButton.Name = "AgregarEstadoButton";
            this.AgregarEstadoButton.SelectedIndex = 0;
            this.AgregarEstadoButton.Size = new System.Drawing.Size(661, 371);
            this.AgregarEstadoButton.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.EstadoMascotaComboBox);
            this.tabPage1.Controls.Add(this.DueñoComboBox);
            this.tabPage1.Controls.Add(this.ListBoxMascotas);
            this.tabPage1.Controls.Add(this.EdadMascotaTextBox);
            this.tabPage1.Controls.Add(this.NombreMascotaTextBox);
            this.tabPage1.Controls.Add(this.EliminarMascota);
            this.tabPage1.Controls.Add(this.EditarMascota);
            this.tabPage1.Controls.Add(this.AgregarMascota);
            this.tabPage1.Location = new System.Drawing.Point(4, 33);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(653, 334);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Mascota";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.EmailDueñoTextBox);
            this.tabPage2.Controls.Add(this.ListBoxDueños);
            this.tabPage2.Controls.Add(this.ApellidoDueñoTextBox);
            this.tabPage2.Controls.Add(this.NombreDueñoTextBox);
            this.tabPage2.Controls.Add(this.EliminarDueño);
            this.tabPage2.Controls.Add(this.EditarDueño);
            this.tabPage2.Controls.Add(this.AgregarDueño);
            this.tabPage2.Location = new System.Drawing.Point(4, 33);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(653, 334);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Dueño";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.ComboBoxEstados);
            this.tabPage3.Controls.Add(this.DescripcionEstadoTextBox);
            this.tabPage3.Controls.Add(this.EliminarEstadoButton);
            this.tabPage3.Controls.Add(this.EditarEstadoButton);
            this.tabPage3.Controls.Add(this.button6);
            this.tabPage3.Location = new System.Drawing.Point(4, 33);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(653, 334);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "EstadoMascota";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // AgregarMascota
            // 
            this.AgregarMascota.Cursor = System.Windows.Forms.Cursors.No;
            this.AgregarMascota.Location = new System.Drawing.Point(111, 205);
            this.AgregarMascota.Name = "AgregarMascota";
            this.AgregarMascota.Size = new System.Drawing.Size(97, 41);
            this.AgregarMascota.TabIndex = 0;
            this.AgregarMascota.Text = "Agregar";
            this.AgregarMascota.UseVisualStyleBackColor = true;
            // 
            // EditarMascota
            // 
            this.EditarMascota.Cursor = System.Windows.Forms.Cursors.No;
            this.EditarMascota.Location = new System.Drawing.Point(20, 247);
            this.EditarMascota.Name = "EditarMascota";
            this.EditarMascota.Size = new System.Drawing.Size(97, 41);
            this.EditarMascota.TabIndex = 1;
            this.EditarMascota.Text = "Editar\r\n";
            this.EditarMascota.UseVisualStyleBackColor = true;
            // 
            // EliminarMascota
            // 
            this.EliminarMascota.Cursor = System.Windows.Forms.Cursors.No;
            this.EliminarMascota.Location = new System.Drawing.Point(123, 273);
            this.EliminarMascota.Name = "EliminarMascota";
            this.EliminarMascota.Size = new System.Drawing.Size(97, 41);
            this.EliminarMascota.TabIndex = 2;
            this.EliminarMascota.Text = "Eliminar";
            this.EliminarMascota.UseVisualStyleBackColor = true;
            // 
            // NombreMascotaTextBox
            // 
            this.NombreMascotaTextBox.Cursor = System.Windows.Forms.Cursors.No;
            this.NombreMascotaTextBox.Location = new System.Drawing.Point(28, 61);
            this.NombreMascotaTextBox.Name = "NombreMascotaTextBox";
            this.NombreMascotaTextBox.Size = new System.Drawing.Size(169, 30);
            this.NombreMascotaTextBox.TabIndex = 3;
            // 
            // EdadMascotaTextBox
            // 
            this.EdadMascotaTextBox.Cursor = System.Windows.Forms.Cursors.No;
            this.EdadMascotaTextBox.Location = new System.Drawing.Point(28, 118);
            this.EdadMascotaTextBox.Name = "EdadMascotaTextBox";
            this.EdadMascotaTextBox.Size = new System.Drawing.Size(169, 30);
            this.EdadMascotaTextBox.TabIndex = 4;
            // 
            // ListBoxMascotas
            // 
            this.ListBoxMascotas.Cursor = System.Windows.Forms.Cursors.No;
            this.ListBoxMascotas.FormattingEnabled = true;
            this.ListBoxMascotas.ItemHeight = 24;
            this.ListBoxMascotas.Items.AddRange(new object[] {
            "Layla",
            "Canela"});
            this.ListBoxMascotas.Location = new System.Drawing.Point(402, 82);
            this.ListBoxMascotas.Name = "ListBoxMascotas";
            this.ListBoxMascotas.Size = new System.Drawing.Size(120, 76);
            this.ListBoxMascotas.TabIndex = 5;
            // 
            // DueñoComboBox
            // 
            this.DueñoComboBox.Cursor = System.Windows.Forms.Cursors.No;
            this.DueñoComboBox.FormattingEnabled = true;
            this.DueñoComboBox.Items.AddRange(new object[] {
            "Romeo "});
            this.DueñoComboBox.Location = new System.Drawing.Point(401, 210);
            this.DueñoComboBox.Name = "DueñoComboBox";
            this.DueñoComboBox.Size = new System.Drawing.Size(121, 32);
            this.DueñoComboBox.TabIndex = 6;
            // 
            // EstadoMascotaComboBox
            // 
            this.EstadoMascotaComboBox.Cursor = System.Windows.Forms.Cursors.No;
            this.EstadoMascotaComboBox.FormattingEnabled = true;
            this.EstadoMascotaComboBox.Items.AddRange(new object[] {
            "Sano",
            "En tratamiento",
            "Enfermito"});
            this.EstadoMascotaComboBox.Location = new System.Drawing.Point(401, 247);
            this.EstadoMascotaComboBox.Name = "EstadoMascotaComboBox";
            this.EstadoMascotaComboBox.Size = new System.Drawing.Size(121, 32);
            this.EstadoMascotaComboBox.TabIndex = 7;
            // 
            // EliminarDueño
            // 
            this.EliminarDueño.Cursor = System.Windows.Forms.Cursors.Help;
            this.EliminarDueño.Location = new System.Drawing.Point(82, 278);
            this.EliminarDueño.Name = "EliminarDueño";
            this.EliminarDueño.Size = new System.Drawing.Size(89, 47);
            this.EliminarDueño.TabIndex = 5;
            this.EliminarDueño.Text = "Eliminar";
            this.EliminarDueño.UseVisualStyleBackColor = true;
            // 
            // EditarDueño
            // 
            this.EditarDueño.Cursor = System.Windows.Forms.Cursors.Help;
            this.EditarDueño.Location = new System.Drawing.Point(28, 225);
            this.EditarDueño.Name = "EditarDueño";
            this.EditarDueño.Size = new System.Drawing.Size(89, 47);
            this.EditarDueño.TabIndex = 4;
            this.EditarDueño.Text = "Editar";
            this.EditarDueño.UseVisualStyleBackColor = true;
            // 
            // AgregarDueño
            // 
            this.AgregarDueño.Cursor = System.Windows.Forms.Cursors.Help;
            this.AgregarDueño.Location = new System.Drawing.Point(64, 172);
            this.AgregarDueño.Name = "AgregarDueño";
            this.AgregarDueño.Size = new System.Drawing.Size(89, 47);
            this.AgregarDueño.TabIndex = 3;
            this.AgregarDueño.Text = "Agregar";
            this.AgregarDueño.UseVisualStyleBackColor = true;
            // 
            // ApellidoDueñoTextBox
            // 
            this.ApellidoDueñoTextBox.Cursor = System.Windows.Forms.Cursors.Help;
            this.ApellidoDueñoTextBox.Location = new System.Drawing.Point(340, 109);
            this.ApellidoDueñoTextBox.Name = "ApellidoDueñoTextBox";
            this.ApellidoDueñoTextBox.Size = new System.Drawing.Size(123, 30);
            this.ApellidoDueñoTextBox.TabIndex = 7;
            // 
            // NombreDueñoTextBox
            // 
            this.NombreDueñoTextBox.Cursor = System.Windows.Forms.Cursors.Help;
            this.NombreDueñoTextBox.Location = new System.Drawing.Point(340, 44);
            this.NombreDueñoTextBox.Name = "NombreDueñoTextBox";
            this.NombreDueñoTextBox.Size = new System.Drawing.Size(123, 30);
            this.NombreDueñoTextBox.TabIndex = 6;
            // 
            // ListBoxDueños
            // 
            this.ListBoxDueños.Cursor = System.Windows.Forms.Cursors.Help;
            this.ListBoxDueños.FormattingEnabled = true;
            this.ListBoxDueños.ItemHeight = 24;
            this.ListBoxDueños.Items.AddRange(new object[] {
            "Romeo mejia 2323@gmail.com",
            "fabricio hernandez 2020@hotmail.com"});
            this.ListBoxDueños.Location = new System.Drawing.Point(308, 225);
            this.ListBoxDueños.Name = "ListBoxDueños";
            this.ListBoxDueños.Size = new System.Drawing.Size(265, 76);
            this.ListBoxDueños.TabIndex = 8;
            // 
            // EmailDueñoTextBox
            // 
            this.EmailDueñoTextBox.Cursor = System.Windows.Forms.Cursors.Help;
            this.EmailDueñoTextBox.Location = new System.Drawing.Point(340, 172);
            this.EmailDueñoTextBox.Name = "EmailDueñoTextBox";
            this.EmailDueñoTextBox.Size = new System.Drawing.Size(123, 30);
            this.EmailDueñoTextBox.TabIndex = 9;
            // 
            // EliminarEstadoButton
            // 
            this.EliminarEstadoButton.Cursor = System.Windows.Forms.Cursors.NoMove2D;
            this.EliminarEstadoButton.Location = new System.Drawing.Point(77, 227);
            this.EliminarEstadoButton.Name = "EliminarEstadoButton";
            this.EliminarEstadoButton.Size = new System.Drawing.Size(92, 40);
            this.EliminarEstadoButton.TabIndex = 8;
            this.EliminarEstadoButton.Text = "Eliminar";
            this.EliminarEstadoButton.UseVisualStyleBackColor = true;
            // 
            // EditarEstadoButton
            // 
            this.EditarEstadoButton.Cursor = System.Windows.Forms.Cursors.NoMove2D;
            this.EditarEstadoButton.Location = new System.Drawing.Point(77, 181);
            this.EditarEstadoButton.Name = "EditarEstadoButton";
            this.EditarEstadoButton.Size = new System.Drawing.Size(92, 40);
            this.EditarEstadoButton.TabIndex = 7;
            this.EditarEstadoButton.Text = "Editar";
            this.EditarEstadoButton.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Cursor = System.Windows.Forms.Cursors.NoMove2D;
            this.button6.Location = new System.Drawing.Point(77, 135);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(92, 40);
            this.button6.TabIndex = 6;
            this.button6.Text = "Agregar";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // DescripcionEstadoTextBox
            // 
            this.DescripcionEstadoTextBox.Cursor = System.Windows.Forms.Cursors.NoMove2D;
            this.DescripcionEstadoTextBox.Location = new System.Drawing.Point(290, 126);
            this.DescripcionEstadoTextBox.Multiline = true;
            this.DescripcionEstadoTextBox.Name = "DescripcionEstadoTextBox";
            this.DescripcionEstadoTextBox.Size = new System.Drawing.Size(158, 49);
            this.DescripcionEstadoTextBox.TabIndex = 9;
            // 
            // ComboBoxEstados
            // 
            this.ComboBoxEstados.Cursor = System.Windows.Forms.Cursors.NoMove2D;
            this.ComboBoxEstados.FormattingEnabled = true;
            this.ComboBoxEstados.Items.AddRange(new object[] {
            "Sano",
            "En tratamiento",
            "Enfermito"});
            this.ComboBoxEstados.Location = new System.Drawing.Point(262, 206);
            this.ComboBoxEstados.Name = "ComboBoxEstados";
            this.ComboBoxEstados.Size = new System.Drawing.Size(186, 32);
            this.ComboBoxEstados.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(258, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "Agregue estado de mascota";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(373, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 24);
            this.label2.TabIndex = 10;
            this.label2.Text = "Nombre";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(373, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 24);
            this.label3.TabIndex = 11;
            this.label3.Text = "Apellido";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(373, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 24);
            this.label4.TabIndex = 12;
            this.label4.Text = "Email";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(800, 478);
            this.Controls.Add(this.AgregarEstadoButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.AgregarEstadoButton.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl AgregarEstadoButton;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ComboBox EstadoMascotaComboBox;
        private System.Windows.Forms.ComboBox DueñoComboBox;
        private System.Windows.Forms.ListBox ListBoxMascotas;
        private System.Windows.Forms.TextBox EdadMascotaTextBox;
        private System.Windows.Forms.TextBox NombreMascotaTextBox;
        private System.Windows.Forms.Button EliminarMascota;
        private System.Windows.Forms.Button EditarMascota;
        private System.Windows.Forms.Button AgregarMascota;
        private System.Windows.Forms.TextBox EmailDueñoTextBox;
        private System.Windows.Forms.ListBox ListBoxDueños;
        private System.Windows.Forms.TextBox ApellidoDueñoTextBox;
        private System.Windows.Forms.TextBox NombreDueñoTextBox;
        private System.Windows.Forms.Button EliminarDueño;
        private System.Windows.Forms.Button EditarDueño;
        private System.Windows.Forms.Button AgregarDueño;
        private System.Windows.Forms.ComboBox ComboBoxEstados;
        private System.Windows.Forms.TextBox DescripcionEstadoTextBox;
        private System.Windows.Forms.Button EliminarEstadoButton;
        private System.Windows.Forms.Button EditarEstadoButton;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}

