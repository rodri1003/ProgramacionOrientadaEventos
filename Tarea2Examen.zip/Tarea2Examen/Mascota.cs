﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea2Examen
{
    public class Mascota
    {
        public int ID { get; set; }
        public string NombreMascota { get; set; }
        public int Edad { get; set; }
        public int DueñoID { get; set; }
        public int EstadoID { get; set; }


    }
}
