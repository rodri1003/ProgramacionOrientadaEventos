﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tarea2Examen
{
    public partial class Form1 : Form
    {
        List<Mascota> listaMascotas = new List<Mascota>();

        List<Dueño> listaDueños = new List<Dueño>();

        List<EstadoMascota> listaEstadosMascotas = new List<EstadoMascota>();



        public Form1()
        {
            InitializeComponent();
            InicializarComboBoxes();
        }


        private void InicializarComboBoxes()
        {
            // Llenar el ComboBox de Dueños 
            DueñoComboBox.Items.Add(new Dueño { ID = 1, NombreCliente = "Gonzalo" });
            DueñoComboBox.Items.Add(new Dueño { ID = 2, NombreCliente = "Fabricio" });

            // Llenar el ComboBox de Estados de Mascota 
            EstadoMascotaComboBox.Items.Add(new EstadoMascota { ID = 1, Descripcion = "Sana" });
            EstadoMascotaComboBox.Items.Add(new EstadoMascota { ID = 2, Descripcion = "En tratamiento" });
            EstadoMascotaComboBox.Items.Add(new EstadoMascota { ID = 3, Descripcion = "Enferma" });
        }
        private void AgregarMascota_Click(object sender, EventArgs e)
        {
            Mascota nuevaMascota = new Mascota();
            nuevaMascota.NombreMascota = NombreMascotaTextBox.Text;
            nuevaMascota.Edad = int.Parse(EdadMascotaTextBox.Text);
            nuevaMascota.DueñoID = ((Dueño)DueñoComboBox.SelectedItem).ID; // Suponiendo que tienes un ComboBox para seleccionar el dueño.
            nuevaMascota.EstadoID = ((EstadoMascota)EstadoMascotaComboBox.SelectedItem).ID; // Suponiendo un ComboBox para seleccionar el estado.

            // Agregar nuevaMascota a la lista de mascotas
            listaMascotas.Add(nuevaMascota);

            // Actualizar el ListBox de mascotas
            ActualizarListBoxMascotas();
        }

        private void EditarMascota_Click(object sender, EventArgs e)
        {
            if (ListBoxMascotas.SelectedIndex != -1)
            {
                Mascota mascotaSeleccionada = (Mascota)ListBoxMascotas.SelectedItem;

                // Actualizar los datos de la mascota seleccionada
                mascotaSeleccionada.NombreMascota = NombreMascotaTextBox.Text;
                mascotaSeleccionada.Edad = int.Parse(EdadMascotaTextBox.Text);
                mascotaSeleccionada.DueñoID = ((Dueño)DueñoComboBox.SelectedItem).ID;
                mascotaSeleccionada.EstadoID = ((EstadoMascota)EstadoMascotaComboBox.SelectedItem).ID;

                // Actualizar el ListBox de mascotas
                ActualizarListBoxMascotas();
            }
        }

        private void EliminarMascota_Click(object sender, EventArgs e)
        {
            if (this.ListBoxMascotas.SelectedIndex != -1)
            {
                Mascota mascotaSeleccionada = (Mascota)this.ListBoxMascotas.SelectedItem;

                // Eliminar la mascota seleccionada de la lista
                listaMascotas.Remove(mascotaSeleccionada);

                // Actualizar el ListBox de mascotas
                ActualizarListBoxMascotas();
            }
        }

        private void ActualizarListBoxMascotas()
        {
            ListBoxMascotas.Items.Clear();
            foreach (Mascota mascota in listaMascotas)
            {
                ListBoxMascotas.Items.Add(mascota);
            }


        }
        private void AgregarDueño_Click(object sender, EventArgs e)
        {
            Dueño nuevoDueño = new Dueño();
            nuevoDueño.NombreCliente = NombreDueñoTextBox.Text;
            nuevoDueño.ApellidoCliente = ApellidoDueñoTextBox.Text;
            nuevoDueño.EmailCliente = EmailDueñoTextBox.Text;

            // Agregar nuevoDueño a la lista de dueños
            listaDueños.Add(nuevoDueño);

            // Actualizar el ListBox de dueños
            ActualizarListBoxDueños();
        }

        private void EditarDueño_Click(object sender, EventArgs e)
        {
            if (ListBoxDueños.SelectedIndex != -1)
            {
                Dueño dueñoSeleccionado = (Dueño)ListBoxDueños.SelectedItem;

                // Actualizar los datos del dueño seleccionado
                dueñoSeleccionado.NombreCliente = NombreDueñoTextBox.Text;
                dueñoSeleccionado.ApellidoCliente = ApellidoDueñoTextBox.Text;
                dueñoSeleccionado.EmailCliente = EmailDueñoTextBox.Text;

                // Actualizar el ListBox de dueños
                ActualizarListBoxDueños();
            }
        }

        private void EliminarDueño_Click(object sender, EventArgs e)
        {
            if (ListBoxDueños.SelectedIndex != -1)
            {
                Dueño dueñoSeleccionado = (Dueño)ListBoxDueños.SelectedItem;

                // Eliminar el dueño seleccionado de la lista
                listaDueños.Remove(dueñoSeleccionado);

                // Actualizar el ListBox de dueños
                ActualizarListBoxDueños();
            }
        }
        private void ActualizarListBoxDueños()
        {
            ListBoxDueños.Items.Clear();
            foreach (Dueño dueño in listaDueños)
            {
                ListBoxDueños.Items.Add(dueño);
            }
        }


        private void AgregarEstadoButton_Click(object sender, EventArgs e)
        {
            EstadoMascota nuevoEstado = new EstadoMascota();
            nuevoEstado.Descripcion = DescripcionEstadoTextBox.Text;

            // Agregar nuevoEstado a la lista de estados de mascotas
            listaEstadosMascotas.Add(nuevoEstado);

            // Actualizar el ComboBox de estados de mascotas
            ActualizarComboBoxEstados();
        }

        private void EditarEstadoButton_Click(object sender, EventArgs e)
        {
            if (ComboBoxEstados.SelectedIndex != -1)
            {
                EstadoMascota estadoSeleccionado = (EstadoMascota)ComboBoxEstados.SelectedItem;

                // Actualizar la descripción del estado de mascota seleccionado
                estadoSeleccionado.Descripcion = DescripcionEstadoTextBox.Text;

                // Actualizar el ComboBox de estados de mascotas
                ActualizarComboBoxEstados();
            }
        }

        private void EliminarEstadoButton_Click(object sender, EventArgs e)
        {
            if (ComboBoxEstados.SelectedIndex != -1)
            {
                EstadoMascota estadoSeleccionado = (EstadoMascota)ComboBoxEstados.SelectedItem;

                // Eliminar el estado de mascota seleccionado de la lista
                listaEstadosMascotas.Remove(estadoSeleccionado);

                // Actualizar el ComboBox de estados de mascotas
                ActualizarComboBoxEstados();
            }
        }
        private void ActualizarComboBoxEstados()
        {
            ComboBoxEstados.Items.Clear();
            foreach (EstadoMascota estado in listaEstadosMascotas)
            {
                ComboBoxEstados.Items.Add(estado);
            }
        }

    }
}
